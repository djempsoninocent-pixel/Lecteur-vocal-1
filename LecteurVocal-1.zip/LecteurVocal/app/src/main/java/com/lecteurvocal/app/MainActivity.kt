package com.lecteurvocal.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.PDFBoxResourceLoader
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

/**
 * Lecteur Vocal Hors-Ligne
 * - Importe un fichier .txt ou .pdf (max 1 Mo) ou du texte saisi/collé
 * - Lit le texte à voix haute (FR / EN-US) via le moteur TTS du système (fonctionne hors-ligne
 *   une fois les packs de voix installés sur l'appareil)
 * - Surligne le mot prononcé en temps réel
 * - Touchez un mot dans le texte pour démarrer la lecture à cet endroit
 *
 * Aucune permission internet n'est utilisée : tout se passe en local sur l'appareil.
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var tvContent: TextView
    private lateinit var etInput: EditText
    private lateinit var spinnerLang: Spinner
    private lateinit var seekSpeed: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnPause: Button
    private lateinit var btnStop: Button
    private lateinit var btnImport: Button
    private lateinit var btnUseTyped: Button
    private lateinit var scrollView: ScrollView

    private var fullText: String = ""
    private var sentences: List<Pair<Int, String>> = emptyList() // (offset dans fullText, phrase)
    private var currentSentenceIndex = 0
    private var currentLocale: Locale = Locale.FRANCE
    private var speechRate = 1.0f

    private var currentSpannable: SpannableString? = null
    private val highlightSpan = BackgroundColorSpan(0x554CAF50.toInt())

    private var downX = 0f
    private var downY = 0f

    private val MAX_FILE_SIZE = 1 * 1024 * 1024 // 1 Mo

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { handleImportedFile(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        PDFBoxResourceLoader.init(applicationContext)

        tvContent = findViewById(R.id.tvContent)
        etInput = findViewById(R.id.etInput)
        spinnerLang = findViewById(R.id.spinnerLang)
        seekSpeed = findViewById(R.id.seekSpeed)
        btnPlay = findViewById(R.id.btnPlay)
        btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop)
        btnImport = findViewById(R.id.btnImport)
        btnUseTyped = findViewById(R.id.btnUseTyped)
        scrollView = findViewById(R.id.scrollView)

        tts = TextToSpeech(this, this)

        val langs = arrayOf("Français", "English (US)")
        spinnerLang.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs)
        spinnerLang.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentLocale = if (position == 0) Locale.FRANCE else Locale.US
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        seekSpeed.max = 150
        seekSpeed.progress = 50 // -> 1.0x
        speechRate = 1.0f
        seekSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speechRate = 0.5f + (progress / 100f)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnImport.setOnClickListener {
            openDocumentLauncher.launch(arrayOf("text/plain", "application/pdf"))
        }

        btnUseTyped.setOnClickListener {
            val typed = etInput.text.toString().trim()
            if (typed.isEmpty()) {
                Toast.makeText(this, "Écrivez ou collez du texte d'abord.", Toast.LENGTH_SHORT).show()
            } else {
                loadNewText(typed)
            }
        }

        btnPlay.setOnClickListener {
            if (sentences.isEmpty()) {
                Toast.makeText(this, "Importez ou saisissez un texte d'abord.", Toast.LENGTH_SHORT).show()
            } else {
                speak(currentSentenceIndex)
            }
        }

        btnPause.setOnClickListener {
            tts.stop()
            setControlsState(playing = false)
        }

        btnStop.setOnClickListener {
            tts.stop()
            currentSentenceIndex = 0
            clearHighlight()
            setControlsState(playing = false)
        }

        tvContent.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val dx = Math.abs(event.x - downX)
                    val dy = Math.abs(event.y - downY)
                    if (dx < 15 && dy < 15) {
                        val layout = (v as TextView).layout
                        if (layout != null && sentences.isNotEmpty()) {
                            val line = layout.getLineForVertical(event.y.toInt())
                            val offset = layout.getOffsetForHorizontal(line, event.x)
                            onWordTapped(offset)
                        }
                    }
                }
            }
            false
        }

        setControlsState(playing = false)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    val idx = utteranceId?.removePrefix("sent_")?.toIntOrNull() ?: return
                    runOnUiThread {
                        currentSentenceIndex = idx + 1
                        if (currentSentenceIndex >= sentences.size) {
                            currentSentenceIndex = 0
                            clearHighlight()
                            setControlsState(playing = false)
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread { setControlsState(playing = false) }
                }

                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    val idx = utteranceId?.removePrefix("sent_")?.toIntOrNull() ?: return
                    val sentenceOffset = sentences.getOrNull(idx)?.first ?: return
                    runOnUiThread { highlightRange(sentenceOffset + start, sentenceOffset + end) }
                }
            })
        } else {
            Toast.makeText(this, "Moteur de synthèse vocale indisponible sur cet appareil.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Lecture ----------

    private fun speak(fromIndex: Int) {
        val result = tts.setLanguage(currentLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Pack vocal manquant pour cette langue. Installation...", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (e: Exception) {
                Toast.makeText(this, "Allez dans Paramètres > Langues > Synthèse vocale pour installer la voix.", Toast.LENGTH_LONG).show()
            }
            return
        }
        tts.setSpeechRate(speechRate)
        tts.stop()
        for (i in fromIndex until sentences.size) {
            val bundle = Bundle()
            tts.speak(sentences[i].second, TextToSpeech.QUEUE_ADD, bundle, "sent_$i")
        }
        currentSentenceIndex = fromIndex
        setControlsState(playing = true)
    }

    private fun onWordTapped(charOffset: Int) {
        if (sentences.isEmpty()) return
        val idx = sentences.indexOfLast { it.first <= charOffset }.let { if (it < 0) 0 else it }
        speak(idx)
    }

    private fun setControlsState(playing: Boolean) {
        btnPlay.isEnabled = !playing
        btnPause.isEnabled = playing
    }

    // ---------- Affichage / surlignage ----------

    private fun displayText(text: String) {
        currentSpannable = SpannableString(text)
        tvContent.text = currentSpannable
    }

    private fun highlightRange(start: Int, end: Int) {
        val spannable = currentSpannable ?: return
        if (start !in 0..spannable.length || end !in 0..spannable.length || start >= end) return
        spannable.removeSpan(highlightSpan)
        spannable.setSpan(highlightSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvContent.text = spannable
        scrollToCharOffset(start)
    }

    private fun clearHighlight() {
        currentSpannable?.let {
            it.removeSpan(highlightSpan)
            tvContent.text = it
        }
    }

    private fun scrollToCharOffset(offset: Int) {
        val layout = tvContent.layout ?: return
        if (offset < 0 || offset > tvContent.text.length) return
        val line = layout.getLineForOffset(offset)
        val y = layout.getLineTop(line)
        scrollView.post { scrollView.smoothScrollTo(0, y) }
    }

    // ---------- Chargement de texte ----------

    private fun loadNewText(text: String) {
        tts.stop()
        fullText = text
        sentences = splitIntoSentences(fullText)
        currentSentenceIndex = 0
        displayText(fullText)
        setControlsState(playing = false)
        Toast.makeText(this, "Texte chargé (${fullText.length} caractères).", Toast.LENGTH_SHORT).show()
    }

    private fun splitIntoSentences(text: String): List<Pair<Int, String>> {
        val result = mutableListOf<Pair<Int, String>>()
        val regex = Regex("[^.!?\\n]+[.!?]+(\\s+|$)|[^.!?\\n]+\\n|[^.!?\\n]+$")
        for (m in regex.findAll(text)) {
            if (m.value.isNotBlank()) result.add(Pair(m.range.first, m.value))
        }
        if (result.isEmpty() && text.isNotBlank()) result.add(Pair(0, text))
        return result
    }

    // ---------- Import de fichiers ----------

    private fun handleImportedFile(uri: Uri) {
        val size = getFileSize(uri)
        if (size > MAX_FILE_SIZE) {
            Toast.makeText(this, "Fichier trop volumineux (max 1 Mo).", Toast.LENGTH_LONG).show()
            return
        }
        val mime = contentResolver.getType(uri) ?: ""
        Toast.makeText(this, "Chargement du fichier...", Toast.LENGTH_SHORT).show()
        Thread {
            val extracted = try {
                if (mime == "application/pdf") extractPdfText(uri) else extractPlainText(uri)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (extracted.isNullOrBlank()) {
                    Toast.makeText(this, "Impossible de lire ce fichier.", Toast.LENGTH_LONG).show()
                } else {
                    loadNewText(extracted)
                }
            }
        }.start()
    }

    private fun getFileSize(uri: Uri): Long {
        var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (idx != -1 && cursor.moveToFirst()) size = cursor.getLong(idx)
        }
        return size
    }

    private fun extractPlainText(uri: Uri): String {
        val sb = StringBuilder()
        contentResolver.openInputStream(uri)?.use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line).append("\n")
                }
            }
        }
        return sb.toString()
    }

    private fun extractPdfText(uri: Uri): String {
        contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                return PDFTextStripper().getText(doc)
            }
        }
        return ""
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
