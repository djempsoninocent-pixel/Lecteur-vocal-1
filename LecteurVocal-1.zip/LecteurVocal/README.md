# Lecteur Vocal Hors-Ligne — Compiler l'APK depuis votre téléphone (gratuit)

Ce projet est déjà complet et prêt à compiler. Vous n'avez besoin d'aucun
ordinateur ni d'Android Studio : un service gratuit (GitHub Actions) va
compiler l'APK pour vous, sur internet, et vous n'aurez plus qu'à le
télécharger sur votre téléphone.

Durée : environ 15-20 minutes, uniquement avec le navigateur de votre téléphone.

## Étape 1 — Créer un compte GitHub (gratuit)

1. Ouvrez votre navigateur, allez sur https://github.com
2. "Sign up" → créez un compte gratuit (e-mail + mot de passe)

## Étape 2 — Créer un nouveau dépôt (repository)

1. Une fois connecté, appuyez sur le **+** en haut → **New repository**
2. Nom : `lecteur-vocal`
3. Visibilité : **Public** (important : la compilation est illimitée et
   gratuite uniquement pour les dépôts publics)
4. Ne cochez aucune case (pas de README, pas de .gitignore)
5. **Create repository**

## Étape 3 — Ajouter les fichiers du projet

Tous les fichiers nécessaires sont dans le dossier `LecteurVocal` fourni
ici. Le plus simple sur téléphone : pour CHAQUE fichier listé ci-dessous,
dans votre dépôt GitHub appuyez sur **Add file > Create new file**, collez
le **chemin complet** dans le champ du nom (GitHub crée les dossiers tout
seul grâce aux `/`), puis collez le contenu du fichier en dessous, et
validez avec **Commit changes**.

Liste des fichiers à créer (chemin → contenu à copier depuis le fichier
correspondant fourni) :

1. `settings.gradle.kts`
2. `build.gradle.kts`
3. `gradle.properties`
4. `app/build.gradle.kts`
5. `app/src/main/AndroidManifest.xml`
6. `app/src/main/res/values/themes.xml`
7. `app/src/main/res/layout/activity_main.xml`
8. `app/src/main/java/com/lecteurvocal/app/MainActivity.kt`
9. `.github/workflows/build-apk.yml`

Astuce : ouvrez chaque fichier fourni dans l'appli Fichiers de votre
téléphone (ou tout lecteur de texte), sélectionnez tout, copiez, puis
collez dans GitHub.

## Étape 4 — Laisser GitHub compiler automatiquement

Dès que vous avez ajouté `.github/workflows/build-apk.yml` (dernier
fichier de la liste), GitHub démarre la compilation tout seul.

1. Dans votre dépôt, appuyez sur l'onglet **Actions**
2. Vous voyez "Build APK" avec un rond orange (en cours) puis vert
   (terminé) après 2-5 minutes
3. Appuyez sur cette exécution terminée

## Étape 5 — Télécharger l'APK

1. Toujours dans cette page Actions, descendez jusqu'à **Artifacts**
2. Appuyez sur `lecteur-vocal-apk` pour le télécharger (un .zip se
   télécharge)
3. Ouvrez ce .zip avec votre gestionnaire de fichiers (option "Extraire")
   → vous obtenez `app-debug.apk`

## Étape 6 — Installer sur votre téléphone

1. Ouvrez `app-debug.apk` depuis votre gestionnaire de fichiers
2. Android demande d'autoriser l'installation depuis cette source
   (à activer une seule fois) → acceptez
3. L'application "Lecteur Vocal" s'installe

## Important — voix hors-ligne

L'application elle-même n'utilise jamais internet. Mais la **voix** vient
du moteur de synthèse vocale déjà présent sur votre téléphone. Si la voix
française ou anglaise n'est pas encore installée :

`Paramètres > Système > Langues et saisie > Sortie de synthèse vocale >
Données vocales > installer Français / English (US)`

À faire une seule fois (nécessite internet ce jour-là). Ensuite, l'app
fonctionne 100 % hors-ligne.

## En cas de problème

- Si l'onglet Actions affiche une croix rouge : ouvrez l'exécution, le
  message d'erreur indique souvent une faute de frappe dans un des
  fichiers collés. Revérifiez le fichier concerné.
- Vous pouvez aussi me dire l'erreur affichée, je vous aiderai à la corriger.

## Limites connues (version 1)

- Fichiers acceptés dans l'app : `.txt` et `.pdf`, 1 Mo maximum chacun
- Le PDF doit contenir du texte réel (pas une image scannée sans OCR)
- Pause : reprend au début de la phrase en cours (pas au mot exact)
